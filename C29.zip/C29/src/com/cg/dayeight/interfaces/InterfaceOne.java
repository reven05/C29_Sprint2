package com.cg.dayeight.interfaces;

public interface InterfaceOne {
	
	//abstract method
	void print();
	
	
	/*concrete method is not allowed in interface
	void show() {
		
	}*/

}
