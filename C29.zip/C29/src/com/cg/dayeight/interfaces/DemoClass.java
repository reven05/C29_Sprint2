package com.cg.dayeight.interfaces;

public class DemoClass {

}
