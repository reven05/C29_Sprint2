package com.cg.dayeight.interfaces;

public class NestedDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NestedInterfaceClass n = new NestedInterfaceClass();
		n.print();
		
	}

}
