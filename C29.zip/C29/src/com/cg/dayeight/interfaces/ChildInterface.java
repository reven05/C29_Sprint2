package com.cg.dayeight.interfaces;

public interface ChildInterface extends InterfaceOne {

	void show();
}
