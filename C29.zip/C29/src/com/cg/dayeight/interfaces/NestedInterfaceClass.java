package com.cg.dayeight.interfaces;

public class NestedInterfaceClass implements NestedInterface.InnerInterface{

	@Override
	public void print() {
		System.out.println("Print Method");
	}

}
