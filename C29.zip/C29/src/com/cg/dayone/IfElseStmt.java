package com.cg.dayone;

public class IfElseStmt {

	public static void main(String[] args) {
		int a = 3, b = 7;  
		System.out.println("Before Condition");
		//if
		if (a>b) {
			System.out.println("True");
		}
		else {
			System.out.println("False");
		}
		System.out.println("After Condition");
	}

}
