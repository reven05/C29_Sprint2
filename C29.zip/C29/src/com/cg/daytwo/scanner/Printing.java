package com.cg.daytwo.scanner;

public class Printing {
	//method name should be a action word(Verb)
	void print() {
		System.out.println("Printing");
	}
	void display() {
		System.out.println("Displaying");
	}
	void add() {
		System.out.println("Adding");
	}

}
