package com.cg.daytwo.scanner;

public class MainClass {

	public static void main(String[] args) {
		Printing p = new Printing();
		p.add();
		p.display();
		p.print();
	}

}
