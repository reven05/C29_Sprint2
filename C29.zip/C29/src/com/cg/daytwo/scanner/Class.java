package com.cg.daytwo.scanner;

public class Class {
	//method
	void hi() {
		System.out.println("Hi Hello C29");
	}
	void welcome() {
		System.out.println("Welcome you all");
	}

	public static void main(String[] args) {
		System.out.println("Main Function");
		
		//object creation
		Class obj = new Class();
		obj.hi();
		obj.welcome();
	}

}
