package com.cg.daythirteen;

public class RunnableDemo {

	public static void main(String[] args) {
		new UsingRunnable(10, 1, "First");
	}

}
