package com.cg.daysix.staticvariables;

public class StudentMain {

	public static void main(String[] args) {
		Student s1 = new Student("Rev", 23);
		Student s2 = new Student("Raj", 20);
		Student s3 = new Student("Preethi", 22);
		Student s4 = new Student("Divya", 12);
		Student s5 = new Student("Ram", 27);
		Student s6 = new Student("Priya", 11);
		Student s7 = new Student("Siva", 15);
		
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
		System.out.println(s4);
		System.out.println(s5);
		System.out.println(s6);
		System.out.println(s7);
		
	}

}
