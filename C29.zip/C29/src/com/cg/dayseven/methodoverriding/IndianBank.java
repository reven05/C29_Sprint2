package com.cg.dayseven.methodoverriding;

public class IndianBank extends RBI{
	@Override
	public float getRateOfIntrest() {
		return 8.9f;
	}
}
